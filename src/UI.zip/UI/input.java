package UI;

import java.util.*;
import java.util.List;

import DataBase.DBBean;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamUtils;
import com.github.sarxos.webcam.util.ImageUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;


public class input {

    private static String PATH = "D:\\work\\Java\\code\\wkr\\";
    private RoundedBorder cut2 = new RoundedBorder("开始拍照");
    private Webcam webcam;
    private ImageIcon imagetoshow;
    private JLabel TipsPicture_label;
    private JLabel Tips_text;
    private WebcamPanel panel;
    private JPanel p2;
    private String finalId;
    public JLabel label_cut = new JLabel("匹 配 静 脉");
    //@DZH
    public ImageIcon imagetoshow2 = new ImageIcon("data_before\\match\\test.png");
    public JLabel picture_cut2 = new JLabel(imagetoshow2);
    /**
     * 构造函数
     *
     * @param webcam  摄像头
     * @param panel   摄像头的Panel
     * @param p2      界面JPanel
     * @param finalId 当前用户的ID
     */
    public input(Webcam webcam, WebcamPanel panel, JPanel p2, String finalId) {
        this.webcam = webcam;
        this.panel = panel;
        this.p2 = p2;
        this.finalId = finalId;
    }

    /**
     * 录入静脉界面
     *
     */
    public void inpanel() {
        p2.updateUI();
        p2.removeAll();
        p2.add(panel);
        label_cut.setBackground(Color.BLACK);
        label_cut.setFont(new Font("隶书", Font.PLAIN, 50));
        label_cut.setBounds(100, 80, 640, 100);
        p2.add(label_cut);
        //cut2.setBackground(new Color(0, 153, 153));
        cut2.setBackground(new Color(205,213,253));
        cut2.setForeground(new Color(0,24,147));
        cut2.setFont(new Font("隶书", Font.PLAIN, 30));
        cut2.setBounds(100, 700, 640, 100);
        p2.add(cut2);
        //        @DZH
        picture_cut2.setBackground(new Color(205,213,253));
        picture_cut2.setBounds(180, 180, 480, 480);
        picture_cut2.setOpaque(false);
        p2.add(picture_cut2);
        p2.add(panel);
    }

    /**
     * 拍照并存储静脉图像
     *
     */
    public void take_picture() {
        imagetoshow = new ImageIcon("gesture\\normal.jpg");
        TipsPicture_label = new JLabel(imagetoshow);
        TipsPicture_label.setBackground(Color.WHITE);
        TipsPicture_label.setBounds(800, 150, 400, 400);

        Tips_text = new JLabel("开始静脉录入");
        Tips_text.setFont(new Font("宋体", Font.PLAIN, 16));
        Tips_text.setBackground(Color.WHITE);
        Tips_text.setBounds(800, 100, 400, 23);

        p2.add(TipsPicture_label);
        p2.add(Tips_text);

        cut2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                action();
            }
        });
    }
    private void action(){
        cut2.setEnabled(false);
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                File file1 = new File("data_before\\" + finalId);
                File file2 = new File("data_after\\" + finalId);
                if (!file1.exists()) file1.mkdir();
                if (!file2.exists()) file2.mkdir();
                for (int j = 0; j < 14; j++) {

                    p2.remove(TipsPicture_label);
                    imagetoshow = new ImageIcon("gesture\\" + (j + 1) + ".png");
                    TipsPicture_label = new JLabel(imagetoshow);
                    TipsPicture_label.setBackground(Color.WHITE);
                    TipsPicture_label.setBounds(800, 150, 400, 400);
                    p2.add(TipsPicture_label);
                    p2.updateUI();
                    try {
                        Thread.sleep(200);
                        //Tips_text.setText(gesture2.get(j / 7) + gesture.get(j % 7) + "，开始拍照");
                    } catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    for (int i = 0; i < 2; i++) {
                        String fileName = "data_before\\" + finalId + "\\" + finalId + "_" + j * i;
                        WebcamUtils.capture(webcam, fileName, ImageUtils.FORMAT_PNG);
                    }
                }
                Tips_text.setText("录入结束");
                File f = new File(PATH + "data_before\\" + finalId);
                Process proc;
                try {
                    String[] args = new String[]{"python",
                            PATH + "process\\process_all_imgs_for_register.py",
                            PATH + "data_before\\" + finalId,
                            PATH + "data_after\\" + finalId};
                    File fa[] = f.listFiles();
                    for (int i = 0; i < fa.length; i++) {//循环遍历
                        File fs = fa[i];//获取数组中的第i
                    }
                    proc = Runtime.getRuntime().exec(args);
                    BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                    String line = null;
                    while ((line = in.readLine()) != null) {
                        System.out.println(line);
                    }
                    in.close();
                    proc.waitFor();
                } catch (IOException ev) {
                    ev.printStackTrace();
                } catch (InterruptedException ev) {
                    ev.printStackTrace();
                }
            }
        });
        th.start();

        cut2.setEnabled(true);
    }
}
