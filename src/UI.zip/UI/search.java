package UI;

import DataBase.DBBean;
import search.table;
import search.returnVector;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class search {
    Object[][] playerInfo = {
            // 创建表格中的数据
            {" ", " ", " "},};
    // 创建表格中的横标题
    String[] Names = {"时间", "体温", "位置"};
    MyJTable table0 = new MyJTable();
    public JTextField search = new JTextField();
    JScrollPane jScrollPane;
    public RoundedBorder sea = new RoundedBorder("查找");
    private DBBean db;

    public search(DBBean db) {
        this.db = db;
    }

    /**
     * 搜索界面
     *
     * @param p2 界面的JPanel
     */
    public void searpanel(JPanel p2) {
        jScrollPane = new JScrollPane(table0);//滚动条
        table0.setShowGrid(false);
        search.setBounds(100, 50, 800, 50);
        search.setFont(new Font("隶书", Font.PLAIN, 20));
        search.setOpaque(false);
        //sea.setBackground(new Color(0, 153, 153));
        sea.setForeground(new Color(0,24,147));
        sea.setBackground(new Color(205,213,253));
        sea.setFont(new Font("隶书", Font.PLAIN, 20));
        sea.setBounds(900, 50, 215, 50);
        p2.add(sea);
        p2.add(search);
        jScrollPane.setBounds(100, 150, 1015, 700);
        jScrollPane.setOpaque(false);
        jScrollPane.getViewport().setOpaque(false);
        p2.add(jScrollPane);
        sea.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name_sea = search.getText();
                p2.remove(jScrollPane);
                table0 = new table(returnVector.getHeadName(db, name_sea), db).returnAllData_table(name_sea);
                table0.setFont(new Font("隶书", Font.PLAIN, 20));
                table0.setShowGrid(false);
                jScrollPane = new JScrollPane(table0);
                jScrollPane.setBounds(100, 150, 1015, 700);
                jScrollPane.setOpaque(false);
                jScrollPane.getViewport().setOpaque(false);
                p2.add(jScrollPane);
            }
        });
    }
}
