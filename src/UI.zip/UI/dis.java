package UI;

import DataBase.DBBean;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamUtils;
import com.github.sarxos.webcam.util.ImageUtils;
import gnu.io.SerialPort;
import serialException.*;
import tem.SerialTool;
import tem.gettem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dis {
    Webcam webcam;
    private static String PATH = "D:\\work\\Java\\code\\wkr\\";
    private SerialPort sp;
    private byte[] data;
    private DBBean db;
    private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
    private boolean test = true;
    private JPanel totalPanel;
    public RoundedBorder cut = new RoundedBorder("启动程序");
    public JLabel label_cut = new JLabel("识 别 静 脉");
    public ImageIcon imagetoshow = new ImageIcon("data_before\\0.png");
    public JLabel picture_cut = new JLabel(imagetoshow);
    public JLabel name_cut = new JLabel("哈哈哈");
    public JLabel tem_cut = new JLabel("36.50");
    RecJPanel gray = new RecJPanel();
    public JLabel nowtime_cut = new JLabel(df.format(new Date()));
    //@DZH
    public ImageIcon imagetoshow2 = new ImageIcon("data_before\\match\\test.png");
    public JLabel picture_cut2 = new JLabel(imagetoshow2);
    gettem gt = new gettem();
    Float tem;

    /**
     * 识别静脉并进行匹配
     *
     * @param webcam0 摄像头
     * @param p2      识别界面的JPanel
     * @param db      数据库
     */
    public void dispanel(Webcam webcam0, JPanel p2, DBBean db, SerialPort sp) {
        this.db = db;
        this.totalPanel = p2;
        this.webcam = webcam0;
        this.sp = sp;
//        @DZH
        picture_cut2.setBackground(new Color(205,213,253));
        picture_cut2.setBounds(180, 180, 480, 480);
        picture_cut2.setOpaque(false);
        p2.add(picture_cut2);
        label_cut.setBackground(Color.BLACK);
        label_cut.setFont(new Font("隶书", Font.PLAIN, 50));
        label_cut.setBounds(100, 80, 640, 100);
        p2.add(label_cut);
        picture_cut.setBounds(908, 100, 200, 200);
        p2.add(picture_cut);
        name_cut.setFont(new Font("隶书", Font.PLAIN, 40));
        name_cut.setBounds(930, 340, 200, 40);
        p2.add(name_cut);
        tem_cut.setFont(new Font("隶书", Font.PLAIN, 50));
        tem_cut.setBounds(930, 480, 140, 50);
        p2.add(tem_cut);
        gray.setBackground(new Color(245,245,245));
        gray.setBounds(920, 470, 140, 70);
        gray.setLayout(null);
        p2.add(gray);
        cut.setBackground(new Color(205,213,253));
        cut.setForeground(new Color(0,24,147));
        cut.setFont(new Font("隶书", Font.PLAIN, 30));
        cut.setBounds(100, 700, 640, 100);
        p2.add(cut);
        nowtime_cut.setBackground(Color.WHITE);
        nowtime_cut.setFont(new Font("宋体", Font.PLAIN, 16));
        nowtime_cut.setBounds(910, 400, 216, 23);
        nowtime_cut.setForeground(new Color(139,137,137));
        p2.add(nowtime_cut);

        cut.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ReadData();
                //@dzh
                cut.setText("终止");
                //SerialTool.closePort(sp);
                return;
            }
        });

    }
    private void ReadData() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (test) {
                    //@dzh
//                    cut.addActionListener(new ActionListener() {
//                        public void actionPerformed(ActionEvent e) {
//                            test = false;
//                            cut.setEnabled(false);
//                        }
//                    });
                    try {
                        data = SerialTool.readFromPort(sp);
                        if (data != null) {
                            gt.printHexString(data);
                            System.out.println();
                            tem = (float) gt.byte2temperature(data) / 100;
                            System.out.println(tem);
                            if (tem > 0) {
                                String fileName1 = PATH + "data_before\\match\\0";
                                WebcamUtils.capture(webcam, fileName1, ImageUtils.FORMAT_PNG);
                                //cut.setEnabled(true);
                                tem = (float) gt.byte2temperature(data) / 100;
                                try {
                                    Thread.sleep(1000);
                                    //把匹配的代码加进
                                    Process proc;
                                    long start_time = System.currentTimeMillis();
                                    String[] args = new String[]{"python", PATH + "process\\process_one_img_for_match.py",
                                            PATH + "data_before\\match\\0.png",//图片路径
                                            PATH + "data_after\\match"};
                                    proc = Runtime.getRuntime().exec(args);
                                    BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                                    String line = null;
                                    String tmp;
                                    while ((tmp = in.readLine()) != null) {
                                        line = tmp;
                                        //line这个参数里面有它匹配到的信息，如果需要的话，
                                        //那个脚本没有办法用类似return这样的语句向java返回参数
                                        //只能通过这样的数据流捕获
                                        System.out.println(line);
                                        //break;
                                    }
                                    in.close();
                                    proc.destroy();
                                    long end_time = System.currentTimeMillis();
                                    System.out.println("Match time:" + (end_time - start_time) / 1000);
                                    String name = null;
                                    ResultSet re = db.executeFind(line, "person", "id");
                                    while (re.next()) {
                                        name = re.getString("name");
                                    }
                                    String finalName = name;
                                    //DZH
                                    db.executeQuery(finalName+"(time,tem,location)", '\'' + df.format(new Date()) + '\'' + ',' + '\'' + String.valueOf(tem) + '\'' + ',' + '\'' + "home" + '\'');
                                    name_cut.setText(finalName);
                                    tem_cut.setText(String.valueOf(tem));
                                    nowtime_cut.setText(df.format(new Date()));
                                    totalPanel.remove(picture_cut);
                                    imagetoshow = new ImageIcon("data_before\\match\\0.png");
                                    JLabel picture_cut = new JLabel(imagetoshow);
                                    picture_cut.setBackground(Color.WHITE);
                                    picture_cut.setBounds(908, 100, 200, 200);
                                    totalPanel.add(picture_cut);
                                    totalPanel.updateUI();
                                    proc.waitFor();
                                    Thread.sleep(9000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                } catch (SQLException throwables) {
                                    throwables.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } catch (ReadDataFromSerialPortFailure readDataFromSerialPortFailure) {
                        readDataFromSerialPortFailure.printStackTrace();
                    } catch (SerialPortInputStreamCloseFailure serialPortInputStreamCloseFailure) {
                        serialPortInputStreamCloseFailure.printStackTrace();
                    }
                }
            }
        }).start();
    }

    private void Action() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String fileName1 = PATH + "data_before\\match\\0";
                WebcamUtils.capture(webcam, fileName1, ImageUtils.FORMAT_PNG);
                //cut.setEnabled(true);
                tem = (float) gt.byte2temperature(data) / 100;
                try {
                    Thread.sleep(1000);
                    //把匹配的代码加进
                    Process proc;
                    long start_time = System.currentTimeMillis();
                    String[] args = new String[]{"python", PATH + "process\\process_one_img_for_match.py",
                            PATH + "data_before\\match\\0.png",//图片路径
                            PATH + "data_after\\match"};
                    proc = Runtime.getRuntime().exec(args);
                    BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                    String line = null;
                    String tmp;
                    while ((tmp = in.readLine()) != null) {
                        line = tmp;
                        //line这个参数里面有它匹配到的信息，如果需要的话，
                        //那个脚本没有办法用类似return这样的语句向java返回参数
                        //只能通过这样的数据流捕获
                        System.out.println(line);
                        //break;
                    }
                    in.close();
                    proc.destroy();
                    long end_time = System.currentTimeMillis();
                    System.out.println("Match time:" + (end_time - start_time) / 1000);
                    String name = null;
                    ResultSet re = db.executeFind(line, "person", "id");
                    while (re.next()) {
                        name = re.getString("name");
                    }
                    String finalName = name;
                    //DZH
                    db.executeQuery(finalName+"(time,tem,location)", '\'' + df.format(new Date()) + '\'' + ',' + '\'' + String.valueOf(tem) + '\'' + ',' + '\'' + "home" + '\'');
                    name_cut.setText(finalName);
                    tem_cut.setText(String.valueOf(tem));
                    nowtime_cut.setText(df.format(new Date()));
                    totalPanel.remove(picture_cut);
                    imagetoshow = new ImageIcon("data_before\\match\\0.png");
                    JLabel picture_cut = new JLabel(imagetoshow);
                    picture_cut.setBackground(Color.WHITE);
                    picture_cut.setBounds(908, 100, 200, 200);
                    totalPanel.add(picture_cut);
                    totalPanel.updateUI();
                    proc.waitFor();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }).start();
    }
}
