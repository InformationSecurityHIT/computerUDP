package UI;
import DataBase.DBBean;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import gnu.io.SerialPort;
import serialException.NoSuchPort;
import serialException.NotASerialPort;
import serialException.PortInUse;
import serialException.SerialPortParameterFailure;
import tem.SerialTool;
import twaver.TWaverUtil;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class uimain {
    private SerialPort sport;
    public JFrame frame;

    public Webcam webcam;
    public WebcamPanel panel;//1&2
    public DBBean db = new DBBean();
    public RoundedBorder btnNewButton = new RoundedBorder("识别静脉");
    public RoundedBorder btnNewButton_1 = new RoundedBorder("录入静脉");
    public RoundedBorder btnNewButton_2 = new RoundedBorder("查看记录");
    public RoundedBorder btnNewButton_3 = new RoundedBorder("隐私保护");
    public MyButton btnNewButton_4 = new MyButton("data_before\\match\\button1.png","data_before\\match\\button2.png","data_before\\match\\button1.png");
    JPanel p1 = new JPanel();//左侧
    JPanel p2;//右侧
    JPanel p3 = new JPanel();
    RecJPanel p4 = new RecJPanel();

    /**
     * 初始化左侧菜单栏
     */
    public void begin() throws Exception {
        frame = new JFrame() {

            private int[] snowX = null;
            private int[] snowY = null;
            private int[] angles = null;
            private int count = 50;

            @Override
            public void paint(Graphics g) {
                super.paint(g);
                Rectangle bounds = frame.getBounds();
                if (snowX == null) {

                    snowX = new int[count];
                    for (int i = 0; i < snowX.length; i++) {
                        snowX[i] = TWaverUtil.getRandomInt(bounds.width);
                    }
                    snowY = new int[count];
                    for (int i = 0; i < snowY.length; i++) {
                        snowY[i] = TWaverUtil.getRandomInt(bounds.height);
                    }
                    angles = new int[count];
                    for (int i = 0; i < snowY.length; i++) {
                        angles[i] = TWaverUtil.getRandomInt(360);
                    }
                }

                Graphics2D g2d = (Graphics2D) g;
                Image image = TWaverUtil.getImage("file:///D:\\work\\Java\\code\\wkr\\data_before\\match\\snow.png");
                for (int i = 0; i < count; i++) {
                    // snowX[i] += TWaverUtil.getRandomInt(5) - 3;
                    snowY[i] += 1;
                    angles[i] += 0;
                    snowY[i] = snowY[i] > bounds.height ? 0 : snowY[i];
                    angles[i] = angles[i] > 360 ? 0 : angles[i];
                    int x = snowX[i];
                    int y = snowY[i];
                    int angle = angles[i];
                    g2d.translate(x, y);
                    double angleValue = Math.toRadians(angle);
                    g2d.rotate(angleValue);
                    g2d.drawImage(image, 0, 0, null);
                    g2d.rotate(-angleValue);
                    g2d.translate(-x, -y);
                }
            }
        };
        p2 = new JPanel();

        Thread thread = new Thread() {

            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(2);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    frame.repaint();
                }
            }
        };

        thread.start();
        frame.getContentPane().setFont(new Font("宋体", Font.PLAIN, 16));
        //@TODO sxz 去除装饰
        //frame.setUndecorated(true); // 去掉窗口的装饰
       // frame.getRootPane().setWindowDecorationStyle(JRootPane.NONE);//采用指定的窗口装饰风格
//        AWTUtilities.setWindowShape(frame, new RoundRectangle2D.Double(
//                0.0D, 0.0D, frame.getWidth(), frame.getHeight(), 26.0D,
//                26.0D));

        frame.setBackground(new Color(236,239,255));
        frame.setTitle("\u624B\u80CC\u9759\u8109\u8BC6\u522B\u4E0E\u6D4B\u6E29\u8F6F\u4EF6");
        frame.getContentPane().setBackground(new Color(236,239,255));
        frame.setBounds(100, 100, 1500, 900);
        p1.setBackground(new Color(236, 239, 255));
        p1.setLayout(null);
        p4.setBackground(new Color(105,89,205));
        p4.setBounds(-40, 100, 400, 800);
        p4.setLayout(null);
        p2.setBounds(257, 0, 1243, 855);
        p2.setBackground(new Color(236, 239, 255));
        p2.setLayout(null);
        p3.setBounds(0, 0, 1243, 855);
        p3.setBackground(new Color(236, 239, 255));
        p3.setLayout(null);
        p2.add(p3);
        p1.add(p4);
        btnNewButton.setFont(new Font("隶书", Font.PLAIN, 25));
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setBackground(new Color(105,89,205));
        btnNewButton.setBounds(0, 50, 400, 50);

        p4.add(btnNewButton);
        btnNewButton_1.setForeground(Color.WHITE);
        btnNewButton_1.setFont(new Font("隶书", Font.PLAIN, 25));
        btnNewButton_1.setBackground(new Color(105,89,205));
        btnNewButton_1.setBounds(0, 135, 400, 50);
        p4.add(btnNewButton_1);
        btnNewButton_2.setForeground(Color.WHITE);
        btnNewButton_2.setFont(new Font("隶书", Font.PLAIN, 25));
        btnNewButton_2.setBackground(new Color(105,89,205));
        btnNewButton_2.setBounds(0, 215, 400, 50);
        p4.add(btnNewButton_2);
        btnNewButton_3.setForeground(Color.WHITE);
        btnNewButton_3.setFont(new Font("隶书", Font.PLAIN, 25));
        btnNewButton_3.setBackground(new Color(105,89,205));
        btnNewButton_3.setBounds(0, 295, 400, 50);
        p4.add(btnNewButton_3);
        btnNewButton_4.setBounds(70, 450, 300, 200);
        p4.add(btnNewButton_4);

        webcam = Webcam.getWebcams().get(0);
        webcam.setViewSize(WebcamResolution.VGA.getSize());
        panel = new WebcamPanel(webcam);
        panel.setFPSDisplayed(true);
        panel.setDisplayDebugInfo(true);
        panel.setImageSizeDisplayed(true);
        panel.setMirrored(false);
        //@DZH
        panel.setOpaque(false);

        openPort();
        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, p1, p2);
        sp.setDividerLocation(360);
        sp.setDividerSize(0);//删除分割线

        frame.add(sp);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        p3.updateUI();
                        panel.setBounds(100, 180, 640, 480);//摄像头
                        p3.removeAll();
                        new dis().dispanel(webcam, p3, db, sport);
                        p3.add(panel);
                    }
                });
            }
        });
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        p3.updateUI();
                        p3.removeAll();
                        panel.setBounds(100, 180, 640, 480);//摄像头
                        new inf(webcam, p3, db, panel).initialize_in();
                    }
                });
            }
        });
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        p3.updateUI();
                        p3.removeAll();
                        new search(db).searpanel(p3);
                    }
                });
            }
        });
    }

    private void openPort() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long start_time = System.currentTimeMillis();
                    sport = SerialTool.openPort("COM4", 9600);
                    long end_time = System.currentTimeMillis();
                    System.out.println(end_time - start_time);
                } catch (SerialPortParameterFailure serialPortParameterFailure) {
                    serialPortParameterFailure.printStackTrace();
                } catch (NotASerialPort notASerialPort) {
                    notASerialPort.printStackTrace();
                } catch (NoSuchPort noSuchPort) {
                    noSuchPort.printStackTrace();
                } catch (PortInUse portInUse) {
                    portInUse.printStackTrace();
                }
            }
        }).start();
    }

}
