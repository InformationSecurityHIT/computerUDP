package android;

import com.googlecode.javacv.FrameGrabber;
import com.googlecode.javacv.OpenCVFrameGrabber;
import com.googlecode.javacv.cpp.opencv_core;

import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class sendOrder {

    private SendOrder_Runnable sendOrder_runnable;
    public sendOrder() {
        ServerSocket serversocket = null;
        Executor executor = null;
        try {
            serversocket = new ServerSocket(8888);//服务器端套接字
            executor = Executors.newCachedThreadPool();
            while (!serversocket.isClosed()) {
                Socket acceptedSocket = serversocket.accept();
                System.out.println("连接成功");
                sendOrder_runnable=new SendOrder_Runnable(acceptedSocket);
                sendOrder_runnable.setMyOrder("222");
                executor.execute(sendOrder_runnable);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (serversocket != null) {
                try {
                    serversocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class SendOrder_Runnable implements Runnable {
        private Socket writeImageSocket;
        private String myOrder=null;

        public SendOrder_Runnable(Socket socket) {
            this.writeImageSocket = socket;
        }

        public void setMyOrder(String myOrder) {
            this.myOrder = myOrder;
        }

        public void run() {
            DataOutputStream dos = null;
            try {
                dos = new DataOutputStream(writeImageSocket.getOutputStream());
                while (myOrder!= null && writeImageSocket.isConnected()) {
                    byte[] data=myOrder.getBytes();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    baos.write(data, 0, data.length);
                    baos.flush();
                    byte[] imageInByte = baos.toByteArray();
                    baos.close();
                    dos.writeInt(imageInByte.length);
                    dos.write(imageInByte, 0, imageInByte.length);
                    System.out.println(dos);
                    dos.flush();
                    Thread.sleep(1000);
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (dos != null) dos.close();
                    writeImageSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
