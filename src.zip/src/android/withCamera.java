package android;

import java.io.*;

import java.net.ServerSocket;

import java.net.Socket;

import java.util.concurrent.Executor;

import java.util.concurrent.Executors;


import javax.imageio.ImageIO;


import DataBase.DBBean;
import com.googlecode.javacv.FrameGrabber.Exception;
import com.googlecode.javacv.cpp.opencv_core.IplImage;
import com.googlecode.javacv.OpenCVFrameGrabber;


public class withCamera {






    private String imgLocation="src\\img\\";//图片的存储位置
    private byte[] imageInByte;//用来存图片的二进制流

    private SendOrder_Runnable sendOrder_runnable;
    private ReceiveRunnable Receive_Runnable;
    private Executor executor = Executors.newCachedThreadPool();//线程池;
    private ServerSocket serversocket = null;
    OpenCVFrameGrabber grabber;
    public DBBean db = new DBBean();
    Socket acceptedSocket;
    private static String PATH = "D:\\Lab\\Info_Security_53\\dzh\\wkr";
    public withCamera() {
        //打开什么摄像头
        grabber = new OpenCVFrameGrabber(0);
        try {
            //创建服务端套接字，之后等待客户端连接
            serversocket = new ServerSocket(8888);
            grabber.start();
            acceptedSocket = serversocket.accept();
//            //发送命令的线程启动
            sendOrder_runnable = new SendOrder_Runnable(acceptedSocket);
            sendOrder_runnable.setMyOrder("222");//设置将要发送的字符串  初始化
            executor.execute(sendOrder_runnable);
            //相机画面的线程启动
            executor.execute(new SendImageRunnable(acceptedSocket, grabber));

            while (!serversocket.isClosed()) {
                Socket acceptedSocket_tmp = serversocket.accept();
                //启动接收客户端数据的线程
                Receive_Runnable=new ReceiveRunnable(acceptedSocket_tmp);
                executor.execute(Receive_Runnable);
            }

        } catch (IOException e) {

            e.printStackTrace();

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            if (serversocket != null) {
                try {
                    serversocket.close();
                    grabber.stop();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 发送摄像头图像数据
     */
    private class SendImageRunnable implements Runnable {
        private Socket writeImageSocket;
        private OpenCVFrameGrabber grabber;


        public SendImageRunnable(Socket socket, OpenCVFrameGrabber grabber) {
            this.writeImageSocket = socket;
            this.grabber = grabber;
        }

        public void run() {
            IplImage image = null;
            DataOutputStream dos = null;
            try {
                dos = new DataOutputStream(writeImageSocket.getOutputStream());
                while ((image = grabber.grab()) != null && writeImageSocket.isConnected()) {
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ImageIO.write(image.getBufferedImage(), "jpg", baos);
                    baos.flush();
                    imageInByte = baos.toByteArray();
                    baos.close();
                    dos.writeInt(imageInByte.length);
                    dos.write(imageInByte, 0, imageInByte.length);
                    dos.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (dos != null) dos.close();
                    writeImageSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 发送字符串
     */
    private class SendOrder_Runnable implements Runnable {
        private Socket writeOrderString_Socket;
        private String myOrder = null;
        private int flag = 0;//为了测试用 偶数发"1111",奇数时候发“2222” 为了验证更新字符串是否好使

        public SendOrder_Runnable(Socket socket) {
            this.writeOrderString_Socket = socket;
        }

        /**
         * 设置要发送的命令字符串
         *
         * @param myOrder 要发送的字符串
         */
        public void setMyOrder(String myOrder) {
            this.myOrder = myOrder;
        }

        public void run() {
            DataOutputStream dos = null;
            try {
                dos = new DataOutputStream(writeOrderString_Socket.getOutputStream());
                while (myOrder != null && writeOrderString_Socket.isConnected()) {
                    byte[] data = myOrder.getBytes();//将字符串转换成二进制数，为了底层发送
                    System.out.println(myOrder);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    baos.write(data, 0, data.length);
                    baos.flush();
                    byte[] orderStringInByte = baos.toByteArray();
                    baos.close();
                    dos.writeInt(orderStringInByte.length);
                    dos.write(orderStringInByte, 0, orderStringInByte.length);
                    dos.flush();
                    Thread.sleep(1000);
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (dos != null) dos.close();
                    writeOrderString_Socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //服务端接收数据线程
    private class ReceiveRunnable extends Thread {

        private Socket severSocket;
        private String receiveString;
        DataInputStream dataInput;

        public ReceiveRunnable(Socket s) throws IOException {
            this.severSocket = s;
            //客户端接收服务端发送的数据的缓冲区
            dataInput = new DataInputStream(
                    s.getInputStream());
        }

        private void saveIMG_inComputer(String img_name){
            //二进制转化为图片
            try (FileOutputStream fileOutputStream =
                         new FileOutputStream(new File(imgLocation+img_name+".jpg"))) {
                fileOutputStream.write(imageInByte);
                System.out.println("success save img "+img_name+".jpg");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            try {
                while (!severSocket.isClosed()) {

                    int size = dataInput.readInt();//获取服务端发送的数据的大小

                    System.out.println("size in client:  " + size);
                    byte[] data = new byte[size];
                    int len = 0;
                    while (len < size) {
                        len += dataInput.read(data, len, size - len);
                    }
                    ByteArrayOutputStream outPut = new ByteArrayOutputStream();
                    receiveString = new String(data);
                    System.out.println(receiveString);
                    function_choose(receiveString);
//                    if (receiveString.length() > 2) {
//                        severSocket.close();
//                        sendOrder_runnable.setMyOrder("i have received" + receiveString);
//                        System.out.println("i have received");
//                    }
                    Thread.sleep(200);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void function_choose(String choice) {
        if (choice == "match") {//匹配
            try {
                //保存图像
                for (int i = 0; i < 7; i++) {
                    //@TODO dzh 调用saveIMG_inComputer
                    Receive_Runnable.saveIMG_inComputer("\\data_before\\new_match\\" + i);
                }
                //匹配
                String return_data = new matchAndroid().match_picture(db,"36.50");
                //发送命令的线程启动
                sendOrder_runnable.setMyOrder(return_data);//设置将要发送的字符串  初始化
                executor.execute(sendOrder_runnable);
            } catch (java.lang.Exception e) {
            }
        } else if (choice == "sign") {
            /**
             * 打开摄像头，拍照，将信息存入文件夹
             */

        }
    }
    public static void main(String[] args) {
        new withCamera();
    }
}