package android;

import DataBase.DBBean;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class matchAndroid {
    private static String PATH = "D:\\Lab\\Info_Security_53\\dzh\\wkr";

    private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
    String finalName;

    /**
     * 匹配
     * @param db
     * @param tem
     * @return
     */
    public String match_picture(DBBean db, String tem) {
        try {
            Thread.sleep(1000);
            //把匹配的代码加进
            Process proc;
            long start_time = System.currentTimeMillis();
            String[] args = new String[]{"python", PATH + "\\process\\process_one_img_for_match.py",
                    PATH + "\\data_before\\new_match",//图片路径
                    PATH + "\\data_before\\match_after"};
            proc = Runtime.getRuntime().exec(args);
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line = null;
            String tmp;
            while ((tmp = in.readLine()) != null) {
                line = tmp;
                //line这个参数里面有它匹配到的信息，如果需要的话，
                //那个脚本没有办法用类似return这样的语句向java返回参数
                //只能通过这样的数据流捕获
                System.out.println(line);
                //break;
            }
            in.close();
            proc.destroy();
            long end_time = System.currentTimeMillis();
            System.out.println("Match time:" + (end_time - start_time) / 1000);
            String name = null;
            ResultSet re = db.executeFind(line, "person", "id");
            while (re.next()) {
                name = re.getString("name");
            }
            finalName = name;
            //DZH
            db.executeQuery(finalName + "(time,tem,location)", '\'' + df.format(new Date()) + '\'' + ',' + '\'' + tem + '\'' + ',' + '\'' + "home" + '\'');
            proc.waitFor();
//            Thread.sleep(9000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return finalName + " " + tem + " " + df.format(new Date());
    }
}
